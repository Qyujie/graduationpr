$("html").niceScroll({
		cursorcolor : "#4ECDC4",
		cursorwidth : '6',
		cursorborderradius : '10px',
		background : '#404040',
		spacebarenabled : false,
		cursorborder : '',
		zindex : '1000',
	});