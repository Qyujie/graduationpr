$(function(){
	var $modalTip = $('<div class="modal-content modal-body" id="ModalTip"></div>');
    $("body").append($modalTip);
});