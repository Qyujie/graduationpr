package pers.qyj.graduationpr.service;



public interface SystemConfigurationService {
	public String getArrivalTime();
	
	public String getDepatureTime();
}
